# Gül Şekerleme Android uygulama paketi

Bu proje, mevcut Cloudflare uygulamasını Android ana ekranında açılan bir uygulama simgesine sarar. Supabase verilerine dokunmaz ve veri silme/aktarma SQL'i çalıştırmaz.

## Önemli
- Bu ZIP **henüz kurulabilir APK dosyası değildir**; APK üretmek için gereken Android proje dosyalarıdır.
- Derleme, projeyi GitHub deposuna yükleyip Actions sekmesinden `Build Gül Şekerleme APK` iş akışını çalıştırarak yapılır. Derleme bitince Artifacts bölümünden APK indirilir.
- Mevcut web uygulamasındaki giriş/şifre sıfırlama hataları bu kabuk tarafından düzeltilmez; web uygulamasının kendisinde düzeltilmelidir.
- APK üretildiğinde GitHub Actions çalışmasının `Artifacts` bölümünde `Gul-Sekerleme-APK` adıyla bulunur.

## Proje
- Paket adı: `com.gulsekerleme.app`
- Başlangıç adresi: `https://gul-sekerleme-panel.pages.dev/`
- İnternet izni vardır; mevcut Cloudflare/Supabase projesini kullanır.
